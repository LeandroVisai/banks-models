# Chatbot RAG — Modo CPU (Testing)

Para probar el chatbot **sin GPU**, usa modo CPU con transformers en lugar de vLLM.

## Instalación rápida

```powershell
cd chatbot

# 1. Instalar dependencias (sin vLLM)
pip install fastapi uvicorn pydantic pydantic-settings
pip install psycopg[binary,pool] pgvector
pip install sentence-transformers torch numpy
pip install transformers

# 2. Activar modo CPU
$env:USE_CPU_LLM=1

# 3. Levantar el chatbot
python -m app.main
```

## Qué sucede

- El chatbot cargará **microsoft/phi-2** (3.8B parámetros) en CPU
- Respuestas serán más lentas (30-60s por query)
- Pero el flujo completo funciona: RAG + SQL + LLM + citas
- Ideal para testing antes de mandar a H100

## Endpoints

El chatbot escucha en `http://localhost:8080`

```bash
# Health check
curl http://localhost:8080/healthz

# Readiness
curl http://localhost:8080/readyz

# Chat simple
curl -X POST http://localhost:8080/chat \
  -H 'Content-Type: application/json' \
  -d '{"message": "¿Cuál fue la TPM en enero 2024?"}'

# Ver historial
curl http://localhost:8080/sessions
```

## Notas

- La base de datos PostgreSQL + pgvector **debe estar corriendo** (rag_banco, tablas qwen_)
- El modelo Qwen3-Embedding-0.6B se carga del `.env` (EMBEDDING_MODEL_ID)
- CPU es **muy lento** — úsalo solo para verificar que todo funciona
- Antes de ir a H100: verificar que los schemas SQL se crean OK, que el retrieval trae chunks, que las series históricas inyectan bien

## Migrar a GPU (H100)

Una vez verificado en CPU:

1. Desactiva `USE_CPU_LLM`
2. Asegúrate de que vLLM + CUDA 12.8 están instalados
3. Descarga el modelo Qwen3.6-35B-A3B
4. Levanta con `python -m app.main` — automáticamente usará vLLM
