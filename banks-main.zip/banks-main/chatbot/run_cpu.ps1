# Script para levantar el chatbot en modo CPU (testing)
# Uso: .\run_cpu.ps1

$ErrorActionPreference = "Stop"

Write-Host "=== Chatbot RAG — Modo CPU ===" -ForegroundColor Cyan

# 1. Verificar que estamos en la carpeta correcta
if (-not (Test-Path "app\main.py")) {
    Write-Host "Error: Ejecuta este script desde la carpeta 'chatbot'" -ForegroundColor Red
    exit 1
}

# 2. Activar modo CPU
Write-Host "`n[1/3] Activando modo CPU (USE_CPU_LLM=1)..." -ForegroundColor Yellow
$env:USE_CPU_LLM=1

# 3. Instalar dependencias (si no están)
Write-Host "[2/3] Instalando dependencias (sin vLLM)..." -ForegroundColor Yellow
pip install -r requirements-cpu.txt --quiet

if ($LASTEXITCODE -ne 0) {
    Write-Host "Error al instalar dependencias" -ForegroundColor Red
    exit 1
}

Write-Host "✓ Dependencias OK" -ForegroundColor Green

# 4. Levantar el chatbot
Write-Host "[3/3] Levantando chatbot en http://localhost:8080" -ForegroundColor Yellow
Write-Host "`n  Health:   curl http://localhost:8080/healthz" -ForegroundColor Gray
Write-Host "  Chat:     curl -X POST http://localhost:8080/chat" -ForegroundColor Gray
Write-Host "  Sessions: curl http://localhost:8080/sessions" -ForegroundColor Gray
Write-Host ""

python -m app.main
