import os
import asyncio

# Forzar backend CPU
os.environ["USE_CPU_LLM"] = "1"
os.environ["CHATBOT_SKIP_DB"] = "1"
from app import settings

# Forzamos el uso del modelo de 2B que acabas de descargar
settings.settings.chatbot_model_name = r"D:\Leandro\models\gemma-2-2b-it"

from app.llm import load_engine, generate
from app.schemas import HistoryMessage

async def main():
    print("Cargando Gemma-2-2b-it. Por favor espera...")
    await load_engine()
    
    # Este es el contexto que recuperamos con el RAG hace un momento
    contexto_rag = """
    1. (...) estuvieron de acuerdo en que la adecuada implementaciÃ³n de la polÃtica monetaria implicaba cumplir con MINUTA REUNIÃ“N DE POLÃ TICA MONETARIA ENERO 2024... Esto podÃa requerir una convergencia anticipada de la TPM, la que llegarÃa a su nivel neutral durante la segunda parte de 2024. Menciona reducciones de 100 puntos base y 125 puntos base, llegando a 7,25%.
    2. De todos modos, el mercado ya habÃa incorporado varios recortes adicionales de la TPM respecto de lo previsto en el IPoM de diciembre, lo que habÃa movido la curva de tasas en la direcciÃ³n adecuada dado el cambio de escenario.
    3. Todos los Consejeros concordaron en que la evoluciÃ³n del escenario macroeconÃ³mico daba cuenta de una inflaciÃ³n que estaba convergiendo a la meta de 3% a una velocidad mayor que la prevista...
    """

    prompt = f"""Eran los analistas del Banco Central. Utiliza el siguiente contexto para responder la pregunta de manera clara y profesional.
Contexto:
{contexto_rag}

Pregunta: Â¿CuÃ¡l fue el acuerdo de la reuniÃ³n de polÃtica monetaria de enero 2024?
"""
    
    from datetime import datetime
    messages = [{"role": "user", "content": prompt}]
    
    print("\nGenerando respuesta...")
    res = await generate(messages, max_tokens=300, temperature=0.3)
    
    print("\n================== RESPUESTA DE GEMMA ==================")
    print(res[0])
    print("========================================================")

if __name__ == "__main__":
    asyncio.run(main())