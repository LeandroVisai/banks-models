"""
Taxonomía compartida: variables económicas, secciones, entidades, patrones numéricos.

Usado por:
  01_enrich_metadata.py — para etiquetar chunks.
  04_search.py          — para parsear queries de usuario.

Los patterns son case/accent-insensitive vía `normalize_text`. Cada pattern
especifica palabras con word-boundaries para evitar falsos positivos
(ej. "tasa" aislada, no "tasador").
"""
from __future__ import annotations

import re
import unicodedata
from typing import Iterable


# ---------------------------------------------------------------------------
# Normalización
# ---------------------------------------------------------------------------

def strip_accents(text: str) -> str:
    """Remueve tildes y diacríticos preservando la letra base."""
    nfd = unicodedata.normalize("NFD", text)
    return "".join(c for c in nfd if unicodedata.category(c) != "Mn")


def normalize_text(text: str) -> str:
    """Lowercase + sin tildes + whitespace colapsado. Para matching robusto."""
    return re.sub(r"\s+", " ", strip_accents(text.lower())).strip()


def compile_word_pattern(words: Iterable[str]) -> re.Pattern:
    """Compila un regex que matchea cualquiera de las palabras con word-boundaries.

    Las palabras de entrada se normalizan (lowercase+sin tildes) para matchear
    contra texto que pase por normalize_text() antes.
    """
    normed = [re.escape(normalize_text(w)) for w in words if w.strip()]
    # \b no funciona bien con caracteres no-ASCII; usamos lookarounds con
    # clase de caracteres de palabra extendida para español sin tildes (ya normalizado).
    return re.compile(
        r"(?<![a-z0-9])(?:" + "|".join(normed) + r")(?![a-z0-9])",
        re.IGNORECASE,
    )


# ---------------------------------------------------------------------------
# Variables económicas (33) con niveles de importancia y tipo de indicador
# ---------------------------------------------------------------------------
# Formato: nombre -> (lista_keywords, importance, indicator_type)
#   importance:      CRITICAL | HIGH | MEDIUM
#   indicator_type:  LEADING | CONTEMPORANEOUS | LAGGING
#
# Keywords pueden ser palabras sueltas o frases; compilamos como alternación.
# Evitamos patterns que matcheen fragmentos (ej. "tasa" como substring de "tasador").

ECONOMIC_VARIABLES: dict[str, tuple[list[str], str, str]] = {
    # --- 18 variables originales (intactas) ---

    "TASA_INTERES": ([
        "tasa de interes", "tasa de politica monetaria", "tpm",
        "interest rate", "policy rate", "federal funds rate",
        "fed funds", "tasa rectora", "tasa de referencia",
        "alza de tasa", "baja de tasa", "recorte de tasa",
        "incremento de tasa", "subida de tasa",
    ], "CRITICAL", "LEADING"),

    "INFLACION": ([
        "inflacion", "ipc", "indice de precios al consumidor",
        "inflation", "cpi", "headline inflation", "core inflation",
        "inflacion subyacente", "presiones inflacionarias",
        "meta de inflacion", "convergencia de la inflacion",
        "inflacion general", "inflacion total",
    ], "CRITICAL", "CONTEMPORANEOUS"),

    "PIB": ([
        "pib", "producto interno bruto", "producto interior bruto",
        "gdp", "gross domestic product", "actividad economica",
        "imacec", "crecimiento economico", "crecimiento del pib",
        "expansion economica", "contraccion economica",
        "dinamica del pib", "recesion", "desaceleracion economica",
        "recuperacion economica", "variacion del pib",
        "output gap", "brecha del producto",
    ], "CRITICAL", "LAGGING"),

    "TIPO_CAMBIO": ([
        "tipo de cambio", "paridad cambiaria", "exchange rate",
        "fx", "usd/clp", "dolar", "depreciacion", "apreciacion",
        "fortalecimiento del dolar", "debilitamiento",
    ], "HIGH", "CONTEMPORANEOUS"),

    "EMPLEO": ([
        "empleo", "desempleo", "tasa de desempleo", "ocupados",
        "unemployment", "employment", "payrolls", "labor market",
        "mercado laboral", "mercado del trabajo", "ocupacion",
        "desocupacion", "fuerza de trabajo", "tasa de participacion",
        "creacion de empleos", "perdida de empleos",
    ], "HIGH", "LAGGING"),

    "EXPECTATIVAS_INFLACIONARIAS": ([
        "expectativas de inflacion", "expectativas inflacionarias",
        "inflation expectations", "breakeven",
        "encuesta de expectativas", "eee", "eof",
        "expectativas de mediano plazo", "expectativas a dos anos",
        "seguros de inflacion", "ber", "break even inflacion",
        "breakeven de inflacion", "compensacion inflacionaria",
    ], "HIGH", "LEADING"),

    "PRECIO_COMMODITIES": ([
        "cobre", "petroleo", "oro", "litio", "copper", "oil", "gold",
        "brent", "wti", "commodity prices", "commodities",
        "materias primas", "precio del cobre", "precio del petroleo",
        "gas natural", "natural gas", "mineral",
    ], "HIGH", "CONTEMPORANEOUS"),

    "POLITICA_FISCAL": ([
        "politica fiscal", "fiscal policy",
        "deficit fiscal", "superavit fiscal", "balance fiscal",
        "balance estructural", "regla fiscal",
        "gasto publico", "gasto fiscal", "government spending",
        "gasto del gobierno", "presupuesto", "ley de presupuestos", "budget",
        "ingresos fiscales", "recaudacion fiscal", "tax revenue",
        "consolidacion fiscal", "ajuste fiscal", "estimulo fiscal", "fiscal stimulus",
        "deuda publica", "public debt", "debt-to-gdp", "deuda como porcentaje",
        "dipres", "tesoreria general",
    ], "HIGH", "LEADING"),

    "DEUDA_SOBERANA": ([
        "deuda soberana", "sovereign debt",
        "riesgo soberano", "riesgo pais", "country risk",
        "cds", "credit default swap", "spread cds",
        "calificacion soberana", "rating soberano", "sovereign rating",
        "calificacion crediticia",
        "moody's", "fitch ratings", "s&p global ratings",
        "spread soberano", "sovereign spread",
        "embi", "embi+", "embi global",
        "downgrade soberano", "upgrade soberano",
        "rebaja de clasificacion", "rebaja de calificacion",
    ], "HIGH", "LAGGING"),

    "CREDITO": ([
        "credito", "prestamos", "credit", "loans", "bank lending",
        "colocaciones", "credito bancario", "acceso al credito",
        "condiciones crediticias", "financial conditions",
        "spread corporativo", "bonos corporativos", "emision corporativa",
        "spread sobre swap", "mercado de capitales", "emision de bonos",
        "cds", "credit default swap", "riesgo soberano", "riesgo pais",
        "spread cds", "bonos en dolares", "financiamiento externo",
        "costo financiamiento exterior", "bonos emitidos en el exterior",
    ], "MEDIUM", "CONTEMPORANEOUS"),

    "INVERSION": ([
        "inversion", "formacion bruta de capital", "investment",
        "capex", "capital expenditure", "inversion fija",
        "inversion privada", "inversion publica", "fbcf",
    ], "MEDIUM", "LAGGING"),

    "BALANZA_COMERCIAL": ([
        "balanza comercial", "exportaciones", "importaciones",
        "trade balance", "exports", "imports", "cuenta corriente",
        "trade war", "aranceles", "tariff", "deficit comercial",
        "superavit comercial", "comercio exterior",
    ], "MEDIUM", "CONTEMPORANEOUS"),

    "TASAS_LARGO_PLAZO": ([
        "tasas a largo plazo", "bonos a 10 anos", "10-year yield",
        "long-term rates", "bond yield", "rendimiento soberano",
        "tasa a 10 anos", "spread soberano", "renta fija",
        "treasury yield",
        "swap", "tasa swap", "curva swap", "spc", "tasa spc",
        "btp", "bcu", "btpcu", "spread sobre swap", "spread sobre spc",
        "tir real", "curva de tasas", "bonos soberanos",
        "tesoro", "tasa tesoro", "treasury", "bono del tesoro",
        "tesoro estadounidense", "10 anos", "rendimiento a 10",
    ], "MEDIUM", "CONTEMPORANEOUS"),

    "CONSUMO": ([
        "consumo privado", "consumo de hogares", "gasto de los hogares",
        "consumer spending", "household consumption",
        "demanda interna", "gasto de consumo", "retail sales",
    ], "MEDIUM", "LAGGING"),

    "VOLATILIDAD": ([
        "volatilidad", "volatility", "vix", "riesgo de mercado",
        "market risk", "incertidumbre", "uncertainty",
        "aversion al riesgo", "risk aversion", "turbulencia",
        "ipsa", "renta variable", "mercado accionario", "bolsa",
        "s&p 500", "nasdaq", "dow jones",
    ], "MEDIUM", "CONTEMPORANEOUS"),

    "LIQUIDEZ": ([
        "liquidez", "liquidity", "funding", "repo",
        "condiciones de liquidez", "mercado monetario",
        "costo de financiamiento", "financiamiento local",
        "spread bonos bancarios", "spread bancario",
        "montos transados", "profundidad de mercado",
        "baja profundidad", "escasos montos", "volumen transado",
    ], "MEDIUM", "CONTEMPORANEOUS"),

    "MERCADO_INMOBILIARIO": ([
        "mercado inmobiliario", "real estate", "housing market",
        "precios de vivienda", "precio de vivienda", "housing prices", "house prices",
        "credito hipotecario", "creditos hipotecarios",
        "mortgage", "mortgage rate", "tasa hipotecaria",
        "construccion", "sector construccion", "construction",
        "edificacion", "permisos de edificacion",
        "vivienda nueva", "vivienda usada",
        "venta de viviendas", "ventas inmobiliarias",
        "ihp", "indice de precios de vivienda",
        "inmobiliario", "inmobiliaria",
    ], "MEDIUM", "CONTEMPORANEOUS"),

    "SECTOR_EXTERNO": ([
        "sector externo", "external sector",
        "balanza de pagos", "balance of payments",
        "deuda externa", "external debt",
        "inversion extranjera directa", "ied", "foreign direct investment", "fdi",
        "remesas", "remittances",
        "flujos de capital", "capital flows", "capital inflows", "capital outflows",
        "salida de capitales", "entrada de capitales",
        "reservas internacionales", "international reserves", "reservas del banco central",
        "cuenta financiera", "financial account",
        "posicion de inversion internacional",
    ], "MEDIUM", "LAGGING"),

    # --- 15 variables nuevas ---

    "TASA_INTERES_MERCADO": ([
        "tasas implicitas", "ois", "swap overnight", "tasa esperada tpm",
        "reunion futura", "forward rate", "curva ois",
        "expectativa de recorte", "expectativa de alza",
    ], "CRITICAL", "LEADING"),

    "LIQUIDEZ_MERCADO": ([
        "liquidez intradia", "operaciones repo", "repos",
        "facilidad permanente", "ventanilla", "flap",
        "fondo de liquidez", "prestamo overnight", "call money",
    ], "CRITICAL", "CONTEMPORANEOUS"),

    "FLUJO_NO_RESIDENTES": ([
        "flujo no residente", "non-resident flows",
        "inversion extranjera de cartera",
        "posicion de no residentes", "compras de no residentes",
        "ventas de no residentes",
    ], "HIGH", "CONTEMPORANEOUS"),

    "FONDO_PENSION": ([
        "afp", "fondos de pensiones", "pension funds",
        "cambio de multifondo", "flujo afp", "traspaso de fondos",
        "fondo a", "fondo b", "fondo c", "fondo d", "fondo e",
    ], "HIGH", "CONTEMPORANEOUS"),

    "MERCADO_NDF": ([
        "ndf", "non-deliverable forward", "forward peso", "forward clp",
        "posicion ndf", "flujo ndf",
        "contrato a plazo no entregable",
    ], "HIGH", "LEADING"),

    "SPREAD_FINANCIERO": ([
        "spread ted", "spread ois-libor", "libor", "ois spread",
        "costo interbancario", "tasa interbancaria", "taip",
    ], "HIGH", "CONTEMPORANEOUS"),

    "INTERVENCION_CAMBIARIA": ([
        "intervencion cambiaria", "programa de compra de dolares",
        "venta de dolares banco central", "compra de reservas",
        "intervencion en el mercado cambiario",
    ], "HIGH", "LEADING"),

    "CONDICIONES_FINANCIERAS": ([
        "indice de condiciones financieras", "financial conditions index",
        "fci", "apertura financiera", "restriccion financiera",
        "condiciones de credito externas",
    ], "HIGH", "LEADING"),

    "CURVA_RENDIMIENTOS": ([
        "curva de rendimientos", "yield curve", "pendiente de la curva",
        "curva swap", "parte corta", "parte larga", "parte media",
        "bclip", "bcliuf", "bcp", "spread 2-10",
    ], "HIGH", "LEADING"),

    "EXPECTATIVAS_PIB": ([
        "expectativas de crecimiento", "growth expectations",
        "proyeccion pib", "consensus growth",
        "encuesta de crecimiento",
    ], "MEDIUM", "LEADING"),

    "PERCEPCION_NEGOCIOS": ([
        "ipn", "percepcion de negocios", "business confidence",
        "confianza empresarial", "imacon",
        "informe de percepciones",
    ], "MEDIUM", "LEADING"),

    "CONFIANZA_CONSUMIDOR": ([
        "confianza del consumidor", "consumer confidence", "ipec",
        "indice de confianza", "percepcion del consumidor",
    ], "MEDIUM", "LEADING"),

    "BALANZA_PAGOS": ([
        "balanza de pagos", "balance of payments", "cuenta de capital",
        "inversion directa",
    ], "MEDIUM", "LAGGING"),

    "PRECIO_ACTIVOS": ([
        "precio de activos", "asset prices", "precio vivienda",
        "indice bursatil", "precio acciones", "p/e",
    ], "MEDIUM", "CONTEMPORANEOUS"),

    "REMESAS": ([
        "remesas", "remittances", "transferencias al exterior",
        "flujo de remesas",
    ], "MEDIUM", "LAGGING"),
}

# Sets precomputados por nivel (para scoring rápido)
CRITICAL_VARIABLES = {k for k, v in ECONOMIC_VARIABLES.items() if v[1] == "CRITICAL"}
HIGH_VARIABLES = {k for k, v in ECONOMIC_VARIABLES.items() if v[1] == "HIGH"}


def build_variable_patterns() -> dict[str, re.Pattern]:
    return {name: compile_word_pattern(v[0]) for name, v in ECONOMIC_VARIABLES.items()}


# ---------------------------------------------------------------------------
# Secciones canónicas (consolidadas, 10 tipos)
# ---------------------------------------------------------------------------
# Cada sección tiene keywords que aumentan el score al matchear.
# Asignamos la sección con mayor score (o CONTENIDO si ninguna matcha).

SECTION_KEYWORDS: dict[str, list[str]] = {
    "ENCABEZADO": [
        "para publicacion", "for release", "embargoed", "press release",
        "correspondiente a la sesion de politica monetaria",
    ],
    "RESUMEN": [
        "resumen ejecutivo", "executive summary", "overview",
        "key takeaways", "bottom line", "en sintesis", "en resumen",
        "principales conclusiones", "key findings",
    ],
    "DECISION": [
        "acordo", "decidio", "resolvio", "aprobo", "voto por",
        "the committee decided", "fomc decided", "policy decision",
        "redujo la tpm", "incremento la tpm", "mantuvo la tasa",
        "recortar la tpm", "bajar la tasa", "subir la tasa",
        "acordar mantener", "la opcion de",
    ],
    "VOTACION": [
        "unanimidad", "disidencia", "disidente", "voto en contra",
        "dissent", "voting member", "voted against", "unanimous",
        "votaron", "voto favorable", "mayoria de los consejeros",
        "todos los consejeros",
    ],
    "CONTEXTO_EXTERNO": [
        "contexto externo", "escenario externo", "economia global",
        "global economy", "international backdrop", "emerging markets",
        "escenario internacional", "entorno externo",
        "fed", "bce", "china", "estados unidos", "zona euro",
        "economia mundial", "world economy", "comercio mundial",
        "mercados financieros internacionales",
    ],
    "CONTEXTO_INTERNO": [
        "contexto interno", "escenario interno", "economia nacional",
        "actividad local", "domestic economy",
        "economia chilena", "actividad economica local",
        "demanda interna", "indicadores locales",
        "en chile", "el pais",
    ],
    "ANALISIS": [
        "analisis", "evaluacion", "assessment", "consejeros evaluaron",
        "discutieron", "comentaron", "en su opinion", "a su juicio",
        "se observa que", "cabe destacar", "es importante",
        "tendencias", "dinamica reciente", "los datos muestran",
        "se señalo", "se comento", "se indico", "se analizo",
        "los consejeros", "los miembros",
    ],
    "PROYECCION": [
        "proyeccion", "perspectivas", "forecast", "outlook",
        "expectativas de", "se espera que", "is expected to",
        "nuestra proyeccion", "we forecast", "horizonte de proyeccion",
        "escenario central", "escenario base", "proyecta que",
        "se estima que", "estimamos", "ipom", "informe de politica",
        "proximo año", "proximos meses", "en los proximos",
    ],
    "RIESGOS": [
        "riesgos", "risks", "downside", "upside",
        "escenarios de riesgo", "tail risk",
        "riesgo al alza", "riesgo a la baja", "riesgo externo",
        "principales riesgos", "factores de riesgo",
        "incertidumbre", "vulnerabilidad",
    ],
    "DATOS": [
        "tabla", "figura", "grafico", "table", "figure", "chart",
        "source:", "fuente:", "ver figura", "see figure",
        "datos muestran", "segun los datos",
    ],
}


def build_section_patterns() -> dict[str, re.Pattern]:
    return {name: compile_word_pattern(words) for name, words in SECTION_KEYWORDS.items()}


# ---------------------------------------------------------------------------
# Entidades (para filtros opcionales y contexto)
# ---------------------------------------------------------------------------

ENTITY_KEYWORDS: dict[str, list[str]] = {
    "BANCO_CENTRAL_CHILE": [
        "banco central de chile", "bcch", "consejo del banco central",
        "reunion de politica monetaria", "rpm", "consejo del bcch",
        "el consejo acordo", "politica monetaria del banco",
    ],
    "FEDERAL_RESERVE": [
        "federal reserve", "the fed", "fomc", "fed funds",
        "jerome powell", "powell",
    ],
    "ECB": ["european central bank", "ecb", "banco central europeo", "bce"],
    "IMF": ["imf", "fmi", "fondo monetario internacional"],
    "BANCO_CHINA": [
        "peoples bank of china", "pboc", "banco popular de china",
        "banco central de china",
    ],
    "BANCO_JAPON": [
        "bank of japan", "boj", "banco de japon",
        "banco central de japon", "banca de japon",
    ],
    "BANCO_INGLATERRA": [
        "bank of england", "boe", "banco de inglaterra",
    ],
    "OCDE": [
        "ocde", "oecd",
        "organizacion para la cooperacion y el desarrollo economicos",
        "paises ocde", "miembros ocde",
    ],
    "BIS": [
        "bank for international settlements",
        "banco de pagos internacionales", "bpi",
        "bis working paper", "bis quarterly",
    ],
    "PERSONA_LAGARDE": [
        "lagarde", "christine lagarde",
    ],
    "PERSONA_BCCH": [
        "rosanna costa", "mario marcel", "alberto naudon",
        "pablo garcia silva", "stephany griffith-jones",
        "presidente del banco central", "presidenta del banco central",
    ],
    "DOCUMENTO_CLAVE_BCCH": [
        "ipom", "informe de politica monetaria",
        "ief", "informe de estabilidad financiera",
        "fcic", "facilidad de credito en condiciones inusuales",
        "ifo", "informe financiero",
        "informe de percepciones de negocios",
    ],
    "PAIS_CHILE": [
        "chile", "chilena", "chileno",
        "clp",             # código ISO del peso chileno
        "ipsa",            # índice bursátil chileno
        "mercado local",   # contexto implícito de Monitor PM
        "curva local",     # curva de tasas local (chilena)
        "paridad local",   # tipo de cambio local (peso)
        "peso local",
    ],
    "PAIS_US": ["estados unidos", "united states", "eeuu", "ee.uu.", "dxy"],
    "PAIS_EUROZONE": ["eurozona", "euro area", "zona euro"],
    "PAIS_CHINA": ["china", "chinese", "beijing"],
    "PAIS_JAPON": ["japon", "japan", "japanese"],
    "PAIS_UK": ["reino unido", "united kingdom", "uk", "great britain", "britain"],
    "PAIS_BRASIL": ["brasil", "brazil", "brazilian", "bcb", "banco central do brasil"],
    "PAIS_LATAM": [
        "america latina", "latin america", "latam",
        "colombia", "peru", "mexico", "argentina", "brasil",
    ],
}


def build_entity_patterns() -> dict[str, re.Pattern]:
    return {name: compile_word_pattern(words) for name, words in ENTITY_KEYWORDS.items()}


# ---------------------------------------------------------------------------
# Patrones numéricos (para extracción de datos cuantitativos)
# ---------------------------------------------------------------------------

NUMERIC_PATTERNS: list[tuple[re.Pattern, str]] = [
    # Porcentajes: "5,25%", "5.25 %", "5,0 por ciento"
    (re.compile(r"(\d{1,3}(?:[.,]\d{1,3})?)\s*(?:%|por ciento|percent)"), "percentage"),
    # Puntos base: "75 puntos base", "75 bps", "75 pb"
    (re.compile(r"(\d{1,4})\s*(?:puntos base|pb\b|bps\b|basis points)"), "basis_points"),
    # Billones/millones (ambigüedad ES/EN; reportamos tal cual aparece)
    (re.compile(r"(\d{1,4}(?:[.,]\d{1,3})*)\s*(billones?|billion)"), "billions"),
    (re.compile(r"(\d{1,4}(?:[.,]\d{1,3})*)\s*(millones?|million)"), "millions"),
    # Montos con símbolo
    (re.compile(r"(?:USD|US\$|\$)\s*(\d{1,4}(?:[.,]\d{1,3})*)"), "usd_amount"),
]

# Palabras que señalan forward-looking / expectativa
FORWARD_LOOKING_KEYWORDS = [
    "se espera", "se proyecta", "se estima", "preve",
    "is expected", "is projected", "we forecast", "we expect",
    "outlook", "perspectivas", "proyeccion",
]

FORWARD_LOOKING_PATTERN = compile_word_pattern(FORWARD_LOOKING_KEYWORDS)

# Texto boilerplate legal/disclaimer/copyright (típico de reportes, PDFs, etc).
# Los chunks que matcheen esto son ruido y deben recibir penalización máxima.
#
# Categorías:
#   - Disclosure de riesgos y legales (JPMorgan, Reuters, etc.)
#   - Copyright, derechos de autor, all rights reserved
#   - Aviso de confidencialidad
#   - Certificación de analista
#   - Advertencia de prospectiva (forward-looking statements)
#   - Contacto/pie de página repetitivo
BOILERPLATE_KEYWORDS = [
    # Disclosure legal / JP Morgan
    "legal entity responsible for the production",
    "this document is being provided for the exclusive use",
    "legal entities disclosures",
    "analyst certification",
    "reg ac research analyst",
    "country-/region-specific disclosures",
    "regulatory disclosures",
    "not regulated activities in your jurisdiction",
    "j.p. morgan securities",
    "jpmorgan chase bank",
    "securities and exchange board",
    # Copyright
    "copyright", "all rights reserved", "derechos reservados",
    "propietario del contenido", "copyright notice",
    # Confidencialidad
    "this message is confidential", "mensaje confidencial",
    "intended recipient", "destinatario autorizado",
    "if you have received this message in error",
    "si ha recibido este mensaje por error",
    # Forward-looking legal disclaimer (a veces en pie de página)
    "forward-looking statements", "declaraciones prospectivas",
    "may contain forward-looking information",
    "past performance is not indicative",
    "rendimiento pasado no es indicativo",
    # Pie de página / contacto estándar
    "for further information please contact",
    "para mas informacion contacte",
    "phone", "email", "extension",
    "telefono", "correo electronico", "extension",
    # Watermark / propiedad intelectual
    "proprietary information", "informacion propietaria",
    "confidential treatment requested", "tratamiento confidencial solicitado",
    "not for distribution", "no para distribucion",
    # Aviso de descargo (típico de research)
    "this publication is distributed",
    "esta publicacion se distribuye",
    "disclaimer", "descargo de responsabilidad",
    "important disclosure", "divulgacion importante",
    # Emails institucionales
    "contacto@", "@bcch", "@bcentral", "@hacienda", "@cmfchile",
    # Pies de página
    "version interna", "uso interno",
    # Formato Excel sobrante
    "hoja:", "pestana:", "worksheet", "tab:", "sheet:",
    # Watermarks
    "borrador", "draft version", "not final", "confidential draft",
]
BOILERPLATE_PATTERN = compile_word_pattern(BOILERPLATE_KEYWORDS)

# Texto que NO es boilerplate sino información de riesgo cuantificable.
# Preservar si contiene un número + variable económica reconocida.
RISK_DISCLOSURE_KEYWORDS = [
    "exposicion a", "exposure to",
    "sensibilidad ante", "sensitivity to",
    "escenario de riesgo", "risk scenario",
    "impacto estimado", "estimated impact",
    "perdida esperada", "expected loss",
    "variacion de", "change in",
]
RISK_DISCLOSURE_PATTERN = compile_word_pattern(RISK_DISCLOSURE_KEYWORDS)

# Secciones propias del Monitor PM (para bonus de importancia base)
MONITOR_PM_SECTIONS: frozenset[str] = frozenset({
    "MERCADO_CAMBIARIO", "TASAS_TPM", "RENTA_FIJA",
    "EXPECTATIVAS_INFLACION", "RENTA_VARIABLE",
    "FINANCIAMIENTO_USD", "FINANCIAMIENTO_EXTERIOR", "FINANCIAMIENTO_PESOS",
    "SPREAD_BONOS", "SPREAD_CORPORATIVO", "RESUMEN",
})


# ---------------------------------------------------------------------------
# Secciones canónicas para Monitor PM (columna → section_type)
# ---------------------------------------------------------------------------
# La clave es el section_title_raw asignado por 00_generate_jsons.py,
# que corresponde exactamente al encabezado de columna del Excel.

MONITOR_PM_SECTION_MAP: dict[str, str] = {
    "Título":                                    "RESUMEN",
    "Mercado Cambiario":                         "MERCADO_CAMBIARIO",
    "Tasas SPC y Expectativas TPM implícita":    "TASAS_TPM",
    "Renta Fija":                                "RENTA_FIJA",
    "Expectativas de Inflación":                 "EXPECTATIVAS_INFLACION",
    "Mercado Renta Variable":                    "RENTA_VARIABLE",
    "Costo Financiamiento en dólares":           "FINANCIAMIENTO_USD",
    "Costo Financiamiento en el exterior":       "FINANCIAMIENTO_EXTERIOR",
    "Costo de Financiamiento en pesos":          "FINANCIAMIENTO_PESOS",
    "Spread bonos bancarios":                    "SPREAD_BONOS",
    "Spreads Corporativos":                      "SPREAD_CORPORATIVO",
}

# Prefijo temporal por tipo de documento (inyectado en embed_text por 02_vectorize.py)
TEMPORAL_SOURCE_PREFIXES: dict[str, str] = {
    "MONITOR_PM":         "[DAILY]",
    "COMUNICADO":         "[PERIOD_MONTHLY]",
    "REPORTE_RESEARCH":   "[PERIOD_MONTHLY]",
    "IPOM":               "[PERIOD_QUARTERLY]",
    "IEF":                "[PERIOD_QUARTERLY]",
    "MINUTAS":            "[PERIOD_MONTHLY]",
}
DEFAULT_TEMPORAL_PREFIX = "[PERIOD_MONTHLY]"


# ---------------------------------------------------------------------------
# Tags (derivados de contenido — conjunto pequeño, no redundante con variables)
# ---------------------------------------------------------------------------
# Estos son banderas booleanas útiles para filtrar, NO re-encoding de variables.

def derive_tags(
    text_norm: str,
    variables: dict,
    numerics: list,
    section_type: str,
) -> list[str]:
    tags: list[str] = []

    if section_type == "DECISION":
        tags.append("DECISION_POLITICA")
    if section_type == "VOTACION":
        tags.append("VOTACION")
    if FORWARD_LOOKING_PATTERN.search(text_norm):
        tags.append("FORWARD_LOOKING")
    if numerics:
        tags.append("DATOS_NUMERICOS")
    if any(v in CRITICAL_VARIABLES for v in variables):
        tags.append("VARIABLE_CRITICA")

    return tags
